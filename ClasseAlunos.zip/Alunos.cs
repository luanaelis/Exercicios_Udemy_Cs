﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClasseAlunos
{
    internal class Alunos
    {
        public string Nome;
        public double Trimestre1;
        public double Trimestre2;
        public double Trimestre3;

        public double NotaFinal()
        {
            return Trimestre1 + Trimestre2 + Trimestre3;
        }

        public double Pontos()
        {
            return 60.0 - NotaFinal();
        }
    }
}
