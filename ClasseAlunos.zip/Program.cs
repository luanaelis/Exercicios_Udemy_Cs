﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Globalization;

namespace ClasseAlunos
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Alunos a = new Alunos();

            Console.Write("Insira o nome do aluno: ");
            a.Nome = Console.ReadLine();
            Console.Write("Insira suas notas: ");
            a.Trimestre1 = double.Parse(Console.ReadLine(), CultureInfo.InvariantCulture);
            a.Trimestre2 = double.Parse(Console.ReadLine(), CultureInfo.InvariantCulture);
            a.Trimestre3 = double.Parse(Console.ReadLine(), CultureInfo.InvariantCulture);

            Console.WriteLine();
            Console.WriteLine("Nota Final = " + a.NotaFinal().ToString("F2", CultureInfo.InvariantCulture));

            if (a.NotaFinal() < 60.0)
            {
                Console.WriteLine("REPROVADO");
                Console.WriteLine("Faltaram " + a.Pontos() + " pontos");
            } else
            {
                Console.WriteLine("APROVADO!");
            }
        }
    }
}
