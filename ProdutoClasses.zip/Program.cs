﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Globalization;

namespace ProdutoClasses
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Produto p1 = new Produto();

            Console.WriteLine("Entre com os dados do seu produto: ");
            Console.Write("Nome do produto? ");
            p1.Nome = Console.ReadLine();
            Console.Write("Preço? ");
            p1.Preco = double.Parse(Console.ReadLine(), CultureInfo.InvariantCulture);
            Console.Write("Quantidade em estoque? ");
            p1.Quantidade = int.Parse(Console.ReadLine());

            Console.WriteLine("Dados do produto: " + p1);

            Console.WriteLine();
            Console.Write("\nDigite o numero de produtos a serem adicionados ao estoque: ");
            int qtd = int.Parse(Console.ReadLine());
            p1.AdicionarProdutos(qtd);
            Console.WriteLine("Dados atualizados: " + p1);

            Console.WriteLine();
            Console.Write("\nDigite o numero de produtos a serem removidos do estoque: ");
            qtd = int.Parse(Console.ReadLine());
            p1.RemoverProdutos(qtd);
            Console.WriteLine("Dados atualizados: " + p1);

        }
    }
}
