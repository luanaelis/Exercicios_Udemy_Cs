﻿namespace ClasseConversorDeMoedas
{
    internal class ConversorDeMoedas
    {
        public static double IOF = 6.0;

        public static double ConversãoReal(double r)
        {
            return (r * IOF / 100.00) + r; 
        }
    }
}
