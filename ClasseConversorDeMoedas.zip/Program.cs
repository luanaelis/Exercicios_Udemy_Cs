﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Globalization;

namespace ClasseConversorDeMoedas
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.Write("Informe a cotação atual do dólar: ");
            double dolar = double.Parse(Console.ReadLine(), CultureInfo.InvariantCulture);
            Console.Write("Quantos dólares você deseja comprar? ");
            double qtd = double.Parse(Console.ReadLine(), CultureInfo.InvariantCulture);

            double real = dolar * qtd;
            real = ConversorDeMoedas.ConversãoReal(real);

            Console.WriteLine("Valor a ser pago em reais: " + real.ToString("F2", CultureInfo.InvariantCulture));


        }
    }
}
