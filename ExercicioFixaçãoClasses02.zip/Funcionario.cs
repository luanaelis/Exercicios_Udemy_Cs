﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ExercicioFixaçãoClasses02
{
    internal class Funcionario
    {
        public string Nome;
        public double Salario;
    }
}
