﻿
namespace TrianguloClasses
{
    internal class Triangulo
    {
        public double A;
        public double B;
        public double C;
    }
}
